from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.db.models import Count
from .forms import MahasiswaForm, DosenForm, MataKuliahForm
from .models import Mahasiswa, Dosen, MataKuliah


@login_required(login_url='/admin/login/')
def dashboard(request):
    semua_mahasiswa = Mahasiswa.objects.all()
    semua_dosen = Dosen.objects.all()
    semua_matkul = MataKuliah.objects.all()
    
    # Statistik distribusi semester
    distribusi_semester = Mahasiswa.objects.values('semester').annotate(
        jumlah=Count('id')
    ).order_by('semester')
    
    # Convert to list for template
    distribusi_semester_list = [
        {
            'semester': item['semester'] if item['semester'] else 'N/A',
            'jumlah': item['jumlah']
        }
        for item in distribusi_semester
    ]
    
    return render(request, 'mahasiswa/dashboard.html', {
        'semua_mahasiswa': semua_mahasiswa,
        'semua_dosen': semua_dosen,
        'semua_matkul': semua_matkul,
        'distribusi_semester': distribusi_semester_list,
    })


# Mahasiswa views
@login_required(login_url='/admin/login/')
def input_mahasiswa(request):
    pesan = ""
    if request.method == 'POST':
        form = MahasiswaForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = "Data mahasiswa berhasil disimpan."
            form = MahasiswaForm()
    else:
        form = MahasiswaForm()

    semua_mahasiswa = Mahasiswa.objects.all().order_by('id')
    return render(request, 'mahasiswa/input.html', {
        'form': form,
        'pesan': pesan,
        'semua_mahasiswa': semua_mahasiswa
    })


@login_required(login_url='/admin/login/')
def hapus_mahasiswa(request, id):
    mhs = get_object_or_404(Mahasiswa, id=id)
    mhs.delete()
    return redirect('input_mahasiswa')


@login_required(login_url='/admin/login/')
def edit_mahasiswa(request, id):
    mhs = get_object_or_404(Mahasiswa, id=id)

    if request.method == 'POST':
        form = MahasiswaForm(request.POST, instance=mhs)
        if form.is_valid():
            form.save()
            return redirect('input_mahasiswa')
    else:
        form = MahasiswaForm(instance=mhs)

    semua_mahasiswa = Mahasiswa.objects.all().order_by('id')
    return render(request, 'mahasiswa/input.html', {
        'form': form,
        'semua_mahasiswa': semua_mahasiswa,
        'edit_mode': True,
        'mahasiswa_id': id,
    })


# Dosen views
@login_required(login_url='/admin/login/')
def dosen_list(request):
    pesan = ''
    if request.method == 'POST':
        form = DosenForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = 'Data dosen berhasil disimpan'
            form = DosenForm()
    else:
        form = DosenForm()
    semua_dosen = Dosen.objects.all().order_by('id')
    return render(request, 'mahasiswa/edit.html', {
        'form': form,
        'semua_dosen': semua_dosen,
        'pesan': pesan,
    })


@login_required(login_url='/admin/login/')
def dosen_create(request):
    pesan = ''
    if request.method == 'POST':
        form = DosenForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = 'Data dosen berhasil disimpan'
            form = DosenForm()
    else:
        form = DosenForm()
    return render(request, 'mahasiswa/edit.html', {
        'form': form,
        'semua_dosen': Dosen.objects.all().order_by('id'),
        'pesan': pesan,
    })


@login_required(login_url='/admin/login/')
def dosen_update(request, id):
    dosen = get_object_or_404(Dosen, id=id)
    if request.method == 'POST':
        form = DosenForm(request.POST, instance=dosen)
        if form.is_valid():
            form.save()
            return redirect('dosen_list')
    else:
        form = DosenForm(instance=dosen)
    return render(request, 'mahasiswa/edit.html', {
        'form': form,
        'semua_dosen': Dosen.objects.all().order_by('id'),
        'edit_mode': True,
        'dosen_id': id,
    })


@login_required(login_url='/admin/login/')
def dosen_delete(request, id):
    dosen = get_object_or_404(Dosen, id=id)
    dosen.delete()
    return redirect('dosen_list')


# Mata Kuliah views
@login_required(login_url='/admin/login/')
def matkul_list(request):
    pesan = ''
    if request.method == 'POST':
        form = MataKuliahForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = 'Data mata kuliah berhasil disimpan'
            form = MataKuliahForm()
    else:
        form = MataKuliahForm()
    semua_matkul = MataKuliah.objects.all().order_by('id')
    return render(request, 'mahasiswa/matkul.html', {
        'form': form,
        'semua_matkul': semua_matkul,
        'pesan': pesan,
    })


@login_required(login_url='/admin/login/')
def matkul_create(request):
    pesan = ''
    if request.method == 'POST':
        form = MataKuliahForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = 'Data mata kuliah berhasil disimpan'
            form = MataKuliahForm()
    else:
        form = MataKuliahForm()
    return render(request, 'mahasiswa/matkul.html', {
        'form': form,
        'semua_matkul': MataKuliah.objects.all().order_by('id'),
        'pesan': pesan,
    })


@login_required(login_url='/admin/login/')
def matkul_update(request, id):
    matkul = get_object_or_404(MataKuliah, id=id)
    if request.method == 'POST':
        form = MataKuliahForm(request.POST, instance=matkul)
        if form.is_valid():
            form.save()
            return redirect('matkul_list')
    else:
        form = MataKuliahForm(instance=matkul)
    return render(request, 'mahasiswa/matkul.html', {
        'form': form,
        'semua_matkul': MataKuliah.objects.all().order_by('id'),
        'edit_mode': True,
        'matkul_id': id,
    })


@login_required(login_url='/admin/login/')
def matkul_delete(request, id):
    matkul = get_object_or_404(MataKuliah, id=id)
    matkul.delete()
    return redirect('matkul_list')


# Logout view
def user_logout(request):
    logout(request)
    return redirect('/admin/login/')
