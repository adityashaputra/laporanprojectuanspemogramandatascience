from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    # Mahasiswa
    path('input/', views.input_mahasiswa, name='input_mahasiswa'),
    path('hapus/<int:id>/', views.hapus_mahasiswa, name='hapus_mahasiswa'),
    path('edit/<int:id>/', views.edit_mahasiswa, name='edit_mahasiswa'),

    # Dosen
    path('dosen/', views.dosen_list, name='dosen_list'),
    path('dosen/tambah/', views.dosen_create, name='dosen_create'),
    path('dosen/edit/<int:id>/', views.dosen_update, name='dosen_update'),
    path('dosen/hapus/<int:id>/', views.dosen_delete, name='dosen_delete'),

    # Mata Kuliah
    path('matkul/', views.matkul_list, name='matkul_list'),
    path('matkul/tambah/', views.matkul_create, name='matkul_create'),
    path('matkul/edit/<int:id>/', views.matkul_update, name='matkul_update'),
    path('matkul/hapus/<int:id>/', views.matkul_delete, name='matkul_delete'),
    
    # Logout
    path('logout/', views.user_logout, name='logout'),
]
