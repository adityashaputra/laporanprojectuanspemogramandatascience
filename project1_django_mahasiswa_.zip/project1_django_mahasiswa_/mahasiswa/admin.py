from django.contrib import admin
from django.urls import path
from django.shortcuts import redirect
from .models import Mahasiswa, Dosen, MataKuliah


# Custom Admin Site
class CustomAdminSite(admin.AdminSite):
    site_header = "SI Akademik - Admin Panel"
    site_title = "SI Akademik Admin"
    index_title = "Selamat datang di Admin Panel"
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('go-to-dashboard/', self.admin_site_dashboard, name='go_to_dashboard'),
        ]
        return custom_urls + urls
    
    def admin_site_dashboard(self, request):
        """Redirect ke dashboard aplikasi"""
        return redirect('/mahasiswa/')
    
    def index(self, request, extra_context=None):
        """Custom index dengan tombol ke dashboard"""
        if extra_context is None:
            extra_context = {}
        extra_context['dashboard_url'] = '/mahasiswa/'
        return super().index(request, extra_context)


# Gunakan custom admin site
admin.site.__class__ = CustomAdminSite


@admin.register(Mahasiswa)
class MahasiswaAdmin(admin.ModelAdmin):
    list_display = ('id', 'nama', 'npm', 'email', 'no_hp', 'jurusan')
    search_fields = ('nama', 'npm', 'email')


@admin.register(Dosen)
class DosenAdmin(admin.ModelAdmin):
    list_display = ('id', 'nama', 'nidn', 'email', 'nohp', 'homebase')
    search_fields = ('nama', 'nidn')


@admin.register(MataKuliah)
class MataKuliahAdmin(admin.ModelAdmin):
    list_display = ('id', 'kode', 'nama', 'sks', 'semester', 'dosen_pengampu')
    search_fields = ('kode', 'nama')
