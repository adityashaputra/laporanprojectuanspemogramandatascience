from django.db import models


class Mahasiswa(models.Model):
    JURUSAN_CHOICES = [
        ('Teknik Informatika', 'Teknik Informatika'),
        ('Sistem Informasi', 'Sistem Informasi'),
        ('Teknik Komputer', 'Teknik Komputer'),
        ('Manajemen Informatika', 'Manajemen Informatika'),
        ('Teknologi Informasi', 'Teknologi Informasi'),
    ]

    nama = models.CharField(max_length=100)
    npm = models.CharField(max_length=20)
    email = models.EmailField()
    no_hp = models.CharField(max_length=20, blank=True, null=True)
    alamat = models.CharField(max_length=255, blank=True, null=True)
    jurusan = models.CharField(max_length=100, choices=JURUSAN_CHOICES, blank=True, null=True)
    semester = models.PositiveSmallIntegerField(default=1, blank=True, null=True)

    def __str__(self):
        return f"{self.nama} ({self.npm})"


class Dosen(models.Model):
    nama = models.CharField(max_length=100)
    nidn = models.CharField(max_length=20, unique=True)
    email = models.EmailField(max_length=100, blank=True, null=True)
    nohp = models.CharField(max_length=15, blank=True, null=True)
    alamat = models.CharField(max_length=255, blank=True, null=True)
    homebase = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        verbose_name = 'Dosen'
        verbose_name_plural = 'Dosen'

    def __str__(self):
        return f"{self.nama} ({self.nidn})"


class MataKuliah(models.Model):
    kode = models.CharField(max_length=20, unique=True)
    nama = models.CharField(max_length=200)
    sks = models.PositiveSmallIntegerField(default=3)
    semester = models.PositiveSmallIntegerField(blank=True, null=True)
    dosen_pengampu = models.ForeignKey(Dosen, on_delete=models.SET_NULL, blank=True, null=True, related_name='mata_kuliah')

    class Meta:
        verbose_name = 'Mata Kuliah'
        verbose_name_plural = 'Mata Kuliah'

    def __str__(self):
        return f"{self.kode} - {self.nama}"
