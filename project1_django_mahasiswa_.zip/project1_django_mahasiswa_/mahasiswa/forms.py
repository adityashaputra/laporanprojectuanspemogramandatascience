from django import forms
from .models import Mahasiswa, Dosen, MataKuliah


class MahasiswaForm(forms.ModelForm):
    class Meta:
        model = Mahasiswa
        fields = ['nama', 'npm', 'email', 'no_hp', 'jurusan', 'semester', 'alamat']
        widgets = {
            'nama': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan nama mahasiswa'}),
            'npm': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan NPM'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan email mahasiswa'}),
            'no_hp': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan nomor HP mahasiswa'}),
            'jurusan': forms.Select(attrs={'class': 'form-select'}),
            'semester': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan semester (1-8)', 'min': '1', 'max': '8'}),
            'alamat': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan alamat'}),
        }
        labels = {
            'nama': 'Nama Lengkap',
            'npm': 'NPM',
            'email': 'Email',
            'no_hp': 'Nomor HP',
            'jurusan': 'Jurusan',
            'semester': 'Semester',
            'alamat': 'Alamat',
        }


class DosenForm(forms.ModelForm):
    class Meta:
        model = Dosen
        fields = ['nama', 'nidn', 'email', 'nohp', 'alamat', 'homebase']
        widgets = {
            'nama': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan nama dosen lengkap'}),
            'nidn': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Contoh: 0123456789'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan email dosen'}),
            'nohp': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Contoh: 081234567890'}),
            'alamat': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan alamat lengkap'}),
            'homebase': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Contoh: Prodi Teknik Informatika'}),
        }
        labels = {
            'nama': 'Nama Dosen',
            'nidn': 'NIDN',
            'email': 'Email',
            'nohp': 'Nomor HP',
            'alamat': 'Alamat',
            'homebase': 'Homebase',
        }


class MataKuliahForm(forms.ModelForm):
    class Meta:
        model = MataKuliah
        fields = ['kode', 'nama', 'sks', 'semester', 'dosen_pengampu']
        widgets = {
            'kode': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Contoh: TI-101'}),
            'nama': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Masukkan nama mata kuliah'}),
            'sks': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'placeholder': '3'}),
            'semester': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'placeholder': '1'}),
            'dosen_pengampu': forms.Select(attrs={'class': 'form-select'}),
        }
        labels = {
            'kode': 'Kode Mata Kuliah',
            'nama': 'Nama Mata Kuliah',
            'sks': 'SKS',
            'semester': 'Semester',
            'dosen_pengampu': 'Dosen Pengampu',
        }

